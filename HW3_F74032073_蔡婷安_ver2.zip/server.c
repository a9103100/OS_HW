#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netdb.h>
#include "status.h"

#define SIZE_OF_BUFFER 128

typedef struct database{
    char domain[100];
    char ipv4[100];
}database;

database d[100];
int count=0;
const char *dtop[] = {"com", "org", "edu", "net", "int", "gov"};

pthread_mutex_t mutex;

static inline int send_response(int cfd, size_t size, const char *response)
{
        if (write(cfd, &size, sizeof(size_t)) == -1)
                return -1;

        if (write(cfd, response, size) == -1)
                return -1;

        return 0;
}

static inline int receive_request(int cfd, size_t *size, char *request)
{
        ssize_t ret;
        ret = read(cfd, size, sizeof(size_t));
        if (ret <= 0)
                return -1;

        ret = read(cfd, request, *size);
        if (ret <= 0)
                return -1;

        return 0;
}

char *lower(char *string)
{
        int i;
        for(i=0;i<strlen(string);i++)
        {
                string[i]=tolower(string[i]);
        }   
        return string;
}

int search(char *input)
{
        int i,output=-1;
        for(i=0;i<count;i++)
        {
                if(strcmp(input,d[i].domain)==0)
                        output=i;
                //printf("%d:%s , %s\n",i,d[i].domain,d[i].ipv4);
        }
        return output;
}

int search_dtop(char *input)
{
        int i,output=-1;
        for(i=0;i<6;i++)
        {
                if(strcmp(input,dtop[i])==0)
                        output=0;
        }
        return output;
}

int digit(char *in)
{
        char *one=malloc(SIZE_OF_BUFFER);  
        char *two=malloc(SIZE_OF_BUFFER);  
        char *three=malloc(SIZE_OF_BUFFER);  
        char *four=malloc(SIZE_OF_BUFFER);  
        char *one_n=malloc(SIZE_OF_BUFFER);  
        char *two_n=malloc(SIZE_OF_BUFFER);  
        char *three_n=malloc(SIZE_OF_BUFFER);  
        char *four_n=malloc(SIZE_OF_BUFFER);
        int c=0,cc=0;
        char *input=malloc(SIZE_OF_BUFFER);
        strcpy(input,in);
        one=strtok(input,".");
        two=strtok(NULL,".");
        three=strtok(NULL,".");
        four=strtok(NULL,".");
        while(one[c]!='\0')
        {
                if(isdigit(one[c])==0)
                        return -1;
                c=c+1;
        }      
        c=0;
        while(two[c]!='\0')
        {
                if(isdigit(two[c])==0)
                        return -1;
                c=c+1;
        }      
        c=0;
        while(three[c]!='\0')
        {
                if(isdigit(three[c])==0)
                        return -1;
                c=c+1;
        }      
        c=0;
        while(four[c]!='\0')
        {
                if(isdigit(four[c])==0)
                        return -1;
                c=c+1;
        }      
        c=0;
        cc=0;
        if(one[0]=='0')
        {
                c=1;
                while(one[c]=='0')
                {
                        c=c+1;
                }
                while(one[c]!='\0')
                {
                        one_n[cc]=one[c];
                        cc=cc+1;
                        c=c+1;
                }
                one_n[cc]='\0';
                if(one_n[0]=='\0')
                {
                        one_n[0]='0';
                        one_n[1]='\0'; 
                } 
        }
        else{
                while(one[c]!='\0')
                {
                        one_n[cc]=one[c];
                        cc=cc+1;
                        c=c+1;
                }
                one_n[cc]='\0';
        }
        c=0;
        cc=0;
        if(two[0]=='0')
        {
                c=1;
                while(two[c]=='0')
                {
                        c=c+1;
                }
                while(two[c]!='\0')
                {
                        two_n[cc]=two[c];
                        cc=cc+1;
                        c=c+1;
                }
                two_n[cc]='\0';
                if(two_n[0]=='\0')
                {
                        two_n[0]='0';
                        two_n[1]='\0'; 
                } 
        }
        else{
                while(two[c]!='\0')
                {
                        two_n[cc]=two[c];
                        cc=cc+1;
                        c=c+1;
                }
                two_n[cc]='\0';
        }
        c=0;
        cc=0;
        if(three[0]=='0')
        {
                c=1;
                while(three[c]=='0')
                {
                        c=c+1;
                }
                while(three[c]!='\0')
                {
                        three_n[cc]=three[c];
                        cc=cc+1;
                        c=c+1;
                }
                three_n[cc]='\0';
                if(three_n[0]=='\0')
                {
                        three_n[0]='0';
                        three_n[1]='\0'; 
                } 
        }
        else{
                while(three[c]!='\0')
                {
                        three_n[cc]=three[c];
                        cc=cc+1;
                        c=c+1;
                }
                three_n[cc]='\0';
        }
        c=0;
        cc=0;
        if(four[0]=='0')
        {
                c=1;
                while(four[c]=='0')
                {
                        c=c+1;
                }
                while(four[c]!='\0')
                {
                        four_n[cc]=four[c];
                        cc=cc+1;
                        c=c+1;
                }
                four_n[cc]='\0';
                if(four_n[0]=='\0')
                {
                        four_n[0]='0';
                        four_n[1]='\0'; 
                } 
        }
        else{
                while(four[c]!='\0')
                {
                        four_n[cc]=four[c];
                        cc=cc+1;
                        c=c+1;
                }
                four_n[cc]='\0';
        }
        char *output=malloc(SIZE_OF_BUFFER);
        //printf("%s\n",one);
        //printf("%s\n",one_n);
        sprintf(output,"%s.%s.%s.%s",one_n,two_n,three_n,four_n);
        strcpy(in,output);
        //printf("%s\n",in);
        return 0;
}

int error_detect_domain(char *in)
{
        int i,c=0,output=-1,cc=0,dot=0;
        char *p;
        char *input=malloc(SIZE_OF_BUFFER);
        char part[30][100];
        strcpy(input,in);
        if(input[0]=='.')
                return -1;
        while(input[c]!='\0')
        {
                c=c+1;
        }       
        if(input[c-1]=='.')
                return -1;
        c=0;
        for(i=0;i<30;i++)
        {
                //part[i]=malloc(SIZE_OF_BUFFER);
                strcpy(part[i],"");
        }
        p=strtok(input,".");
        strcpy(part[0],p);       
        //printf("%s\n",part[0]); 
        while(p!=NULL)
        {       
                c=c+1;
                p=strtok(NULL,".");
                if(p!=NULL)                
                        strcpy(part[c],p);
        }
        while(in[cc]!='\0')
        {
                if(in[cc]=='.')
                        dot=dot+1;
                cc=cc+1;
        }
        c=c-1;
        if(dot!=c)
                return -1;
        //printf("%s\n",part[1]);
        printf("%d\n",c);
        if(strcmp(part[1],"\0")==0)
        {
                output=-1;
                //printf("-1\n");
                return output;
        }
        else
        {
                output=search_dtop(part[c]);
        }
        return output;
}

int error_detect_ipv4(char *in)
{
        int i,c=0,output=-1,cc=0;
        char *p;
        char *input=malloc(SIZE_OF_BUFFER);
        char part[30][100];
        int part_int[30];
        strcpy(input,in);
        if(input[0]=='.')
                return -1;
        while(input[c]!='\0')
        {
                if(input[c]=='.')
                        cc=cc+1;
                c=c+1;
        }
        if(cc!=3)
                return -1;
        c=0;
        for(i=0;i<30;i++)
        {
                //part[i]=malloc(SIZE_OF_BUFFER);
                strcpy(part[i],"");
        }
        p=strtok(input,".");
        strcpy(part[0],p);       
        //printf("%s\n",part[0]); 
        while(p!=NULL)
        {       
                c=c+1;
                p=strtok(NULL,".");
                if(p!=NULL)                
                        strcpy(part[c],p);
        }
        c=c-1;
        //printf("%s\n",part[1]);
        //printf("%d\n",c);
        if(c==3)
        {        
                if(strcmp(part[1],"\0")==0)
                {
                        output=-1;
                        //printf("-1\n");
                        return output;
                }
                else
                {
                        for(i=0;i<=c;i++)
                        {              
                                part_int[i]=atoi(part[i]);
                        }
                        for(i=0;i<=c;i++)
                        {
                                if(part_int[i]>255||part_int[i]<0)
                                {
                                        output=-1;
                                        return output;
                                }
                                else 
                                        output=0;
                        }
                }
        }
        else
                output=-1;
        return output;
}

void *check(void *fd)
{       
        while(1){
                size_t size = SIZE_OF_BUFFER;
                size_t size_request, size_response;
                char *request = malloc(SIZE_OF_BUFFER);
                char *response = malloc(SIZE_OF_BUFFER);
                char *type = NULL;
                char *domain = NULL;
                char *ipv4 = NULL;
                int c,detect_domain,detect_ipv4,detect_digit;
                int cfd=(int)fd;
                receive_request(cfd,&size_request,request);
                //printf("%s\n",request);
                type = strtok(request," ");
                domain = strtok(NULL," ");
                ipv4 = strtok(NULL," ");
                //printf("%s\n",request);
                printf("type:%s , domain:%s , ipv4:%s\n",type,domain,ipv4);
                if(type==NULL)
                {
                        /*sprintf(response,"%d \"%s\"",status_code[BAD_REQUEST],status_str[BAD_REQUEST]);
                        size_response = strlen(response);
                        send_response(cfd,size_response,response);
                        printf("%s\n",response);    
                        pthread_mutex_unlock(&mutex);*/
                        return NULL;    
                }
                else{
                        pthread_mutex_lock(&mutex);
                        if(strcmp(type,"SET")==0)
                        {
                                if(domain!=NULL&&ipv4!=NULL)
                                {
                                        lower(domain); 
                                        detect_domain=error_detect_domain(domain);
                                        detect_ipv4=error_detect_ipv4(ipv4);
                                        if(detect_ipv4!=-1)
                                                detect_digit=digit(ipv4);
                                        //printf("%s\n",ipv4);
                                        detect_ipv4=error_detect_ipv4(ipv4);
                                        if(detect_domain==-1||detect_ipv4==-1||detect_digit==-1)
                                        {
                                                sprintf(response,"%d \"%s\"",status_code[BAD_REQUEST],status_str[BAD_REQUEST]);
                                                size_response = strlen(response);
                                                send_response(cfd,size_response,response);
                                                printf("%s\n",response);
                                        }
                                        else
                                        {                        
                                                c=search(domain);
                                                if(c==-1)
                                                {                        
                                                        sprintf(d[count].domain,"%s",domain);
                                                        sprintf(d[count].ipv4,"%s",ipv4);
                                                        //printf("%s\n",d[count].domain);
                                                        //printf("%s\n",d[count].ipv4);
                                                        count = count + 1;
                                                        //printf("SET\n");
                                                        sprintf(response,"%d \"%s\"",status_code[OK],status_str[OK]);
                                                        size_response = strlen(response);
                                                        send_response(cfd,size_response,response);
                                                        printf("%s\n",response);
                                                }
                                                else
                                                {
                                                        strcpy(d[c].ipv4,ipv4);
                                                        sprintf(response,"%d \"%s\"",status_code[OK],status_str[OK]);
                                                        size_response = strlen(response);
                                                        send_response(cfd,size_response,response);
                                                        printf("%s\n",response);
                                                }
                                        }
                                }
                                else
                                {
                                        sprintf(response,"%d \"%s\"",status_code[BAD_REQUEST],status_str[BAD_REQUEST]);
                                        size_response = strlen(response);
                                        send_response(cfd,size_response,response);
                                        printf("%s\n",response);
                                }
                        }
                        else if(strcmp(type,"GET")==0)
                        {
                                if(domain!=NULL)
                                        lower(domain); 
                                if(domain==NULL)
                                {
                                        sprintf(response,"%d \"%s\"",status_code[BAD_REQUEST],status_str[BAD_REQUEST]);
                                        size_response = strlen(response);
                                        send_response(cfd,size_response,response);
                                        printf("%s\n",response);
                                }
                                else if(ipv4!=NULL)
                                {
                                        sprintf(response,"%d \"%s\"",status_code[BAD_REQUEST],status_str[BAD_REQUEST]);
                                        size_response = strlen(response);
                                        send_response(cfd,size_response,response);
                                        printf("%s\n",response);
                                }
                                else
                                {
                                        c=search(domain);
                                        if(c==-1)
                                        {
                                                sprintf(response,"%d \"%s\"",status_code[NOT_FOUND],status_str[NOT_FOUND]);
                                                size_response = strlen(response);
                                                send_response(cfd,size_response,response);
                                                printf("%s\n",response);
                                        }
                                        else
                                        {
                                                sprintf(response,"%d \"%s\" %s",status_code[OK],status_str[OK],d[c].ipv4);
                                                size_response = strlen(response);
                                                send_response(cfd,size_response,response);
                                                printf("%s\n",response);
                                        }
                                }
                                //printf("GET\n");
                        }
                        else if(strcmp(type,"INFO")==0)
                        {
                                if(domain==NULL&&ipv4==NULL)
                                {
                                        sprintf(response,"%d \"%s\" %d",status_code[OK],status_str[OK],count);
                                        size_response = strlen(response);
                                        send_response(cfd,size_response,response);
                                        printf("%s\n",response);
                                }
                                else
                                {
                                        sprintf(response,"%d \"%s\"",status_code[BAD_REQUEST],status_str[BAD_REQUEST]);
                                        size_response = strlen(response);
                                        send_response(cfd,size_response,response);
                                        printf("%s\n",response);
                                }
                                //printf("INFO\n");
                        }  
                        else
                        {   
                                sprintf(response,"%d \"%s\"",status_code[METHOD_NOT_ALLOWED],status_str[METHOD_NOT_ALLOWED]);
                                //strcat(response,"METHOD NOT ALLOWED");
                                size_response = strlen(response);
                                send_response(cfd,size_response,response);
                                printf("%s\n",response);
                        }
                        //sleep(5);
                        pthread_mutex_unlock(&mutex);
                }
        }
        return NULL;
}

int connect_client(const char *host, const char *port)
{
        struct addrinfo hints;
        struct addrinfo *result, *rp;
        struct sockaddr *peer_addr;
        socklen_t peer_addr_size;
        int s, sfd, cfd;
        size_t size = SIZE_OF_BUFFER;
        size_t size_request, size_response;
        char *request = malloc(SIZE_OF_BUFFER);
        char response[SIZE_OF_BUFFER];
        int reuseaddr;

        memset(&hints, 0, sizeof(struct addrinfo));
        hints.ai_family = AF_UNSPEC;     
        hints.ai_socktype = SOCK_STREAM; 
        hints.ai_flags = AI_PASSIVE;
        hints.ai_protocol = 0;         

        s = getaddrinfo(host, port, &hints, &result);
        if (s != 0) {
                fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
                exit(EXIT_FAILURE);
        }  
        
        for (rp = result; rp != NULL; rp = rp->ai_next) {
                sfd = socket(rp->ai_family, rp->ai_socktype,
                                rp->ai_protocol);

                setsockopt(sfd,SOL_SOCKET,SO_REUSEADDR,&reuseaddr,sizeof(reuseaddr));                
                
                if (sfd == -1)
                        continue;

                if (bind(sfd, rp->ai_addr, rp->ai_addrlen) == 0)
                {                       
                        break;          /* Success */
                }
                close(sfd);
        }

        if (rp == NULL) {               /* No address succeeded */
               fprintf(stderr, "Could not bind\n");
               exit(EXIT_FAILURE);
        }
        if (listen(sfd, 20) == -1) {
               fprintf(stderr, "listen failed\n");
               exit(EXIT_FAILURE);
        } 
        while(1){    
                pthread_t thread; 
                cfd = accept(sfd, peer_addr, &peer_addr_size);
                if(cfd!=-1)                
                        pthread_create(&thread,NULL,check,(void *) cfd);  
        }

        freeaddrinfo(result);

        return 0;
}

int main(int argc, char *argv[])
{
        const char *server = "127.0.0.1", *port = "12345";
        pthread_mutex_init(&mutex,NULL);
        connect_client(server,port);
        pthread_mutex_destroy(&mutex);
        return 0;
}

