#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
	while(1)
	{
		printf("0$ ");
		int i,count=0,bar_count=0,bigger_count=0,smaller_count=0;
		int pfd[2];
		char* command[100];  
		char input[100];  //輸入的指令
		fgets(input,100,stdin);
		
		for(i=0;i<100;i++)
		{
            		//printf("%c,",input[i]);
			if(input[i]=='|')
				bar_count=bar_count+1;
		}
		for(i=0;i<100;i++)
		{
			if(input[i]=='>')
				bigger_count=bigger_count+1;
		}
        	for(i=0;i<100;i++)
		{
			if(input[i]=='<')
			{
				smaller_count=smaller_count+1;
				//printf("%c",input[i]);
			}
		}
 	        printf("%d,%d,%d\n",bar_count,bigger_count,smaller_count);
		//printf("%s",command[0]);	
		if(bar_count==0&&bigger_count==0&&smaller_count==3)
		{
            		command[0]=strtok(input, " ");
		    	//printf("%s",command[0]);
		   	 while(command[count]!='\0')
		    	{
		   		count=count+1;
			    	command[count]=strtok(NULL, " ");
		    		//printf("%s",command[count]);
	    		}
		    	command[count-1]=strtok(command[count-1],"\n");
		    	command[count]=NULL;

			pid_t child; //產生出來的process的名字
			child = fork();
			if(child==0)
			{
				if(strcmp(command[0],"exit")==0)
					exit(0);		
				if(strcmp(command[0],"cd")==0)
					chdir(command[1]);
				else
					execvp(command[0],command);
			}
			else
			{
				wait(NULL);
				if(strcmp(command[0],"exit")==0)
					exit(0);		
			}
		}
		else if(bar_count==0&&bigger_count>0&&smaller_count==3)
		{
			char command2[2][100];
			char* cmd[100];
           		command[0]=strtok(input,">");
			command[1]=strtok(NULL,">");
			strcpy(command2[0],command[0]);
			strcpy(command2[1],command[1]);
			strcpy(command2[1],strtok(command2[1],"\n")); 
			cmd[0]=strtok(command2[0]," ");
			while(cmd[count]!='\0')
			{
				count=count+1;
				cmd[count]=strtok(NULL," ");
			}
			//FILE *fptr;
			//fptr=fopen(command2[1],"w");
			//char a[1000];
			//strcpy(a,execvp(cmd[0],cmd));
			//fprintf(fptr,a);
			//fclose(fptr);
            		pid_t child; //產生出來的process的名字
			child = fork();
			pipe(pfd);
			if(child==0)
			{	
				close(pfd[0]);
				dup2(1,STDIN_FILENO);
				dup2(pfd[1],STDOUT_FILENO);
				execvp(cmd[0],cmd);
				FILE *fptr;
				fptr=fopen(command2[1],"w");
				fprintf(fptr,pfd[1]);
				fclose(fptr);
			}
			else
			{
				close(pfd[1]);
				wait(NULL);
			}
		}
        	else if(bar_count==0&&bigger_count==0&&smaller_count>3)
		{
			char command2[2][100];
			char* cmd[100];
           		command[0]=strtok(input,"<");
			command[1]=strtok(NULL,"<");
			strcpy(command2[0],command[0]);
			strcpy(command2[1],command[1]);
			strcpy(command2[1],strtok(command2[1],"\n")); 
			cmd[0]=strtok(command2[0]," ");
			while(cmd[count]!='\0')
			{
				count=count+1;
				cmd[count]=strtok(NULL," ");
			}
			FILE *fptr;
			char data[1000];
			fptr=fopen(command2[1],"r");
			for(i=0;i<1000;i++)
				fscanf(fptr,"%c",&data[i]);
			fclose(fptr);
		}
		else
		{
			int cmd_count=bar_count+1;
			char command1[cmd_count][100]; //temp 
			char* cmd[100];
            		command[0]=strtok(input, "|");
			for(i=1;i<cmd_count;i++)
			{
                		command[i]=strtok(NULL, "|");
                		//printf("%s ,",command[i]);
			}
			for(i=0;i<cmd_count;i++)
			{
				strcpy(command1[i],command[i]);
				//printf("%s,",command1[i]);
			}
			int in;   //handan & kiroku (japanese)
			//pipe(pfd);
            		for(i=0;i<cmd_count;i++)
            		{
				count=0;
                		cmd[0]=strtok(command1[i], " ");
		        	//printf("%s,",cmd[0]);
		                while(cmd[count]!='\0')
		             	{
			        	count=count+1;
			          	cmd[count]=strtok(NULL, " ");
		    	        	//printf("%s,",cmd[count]);
	    	        	}
				if(i==cmd_count-1){
		          		cmd[count-1]=strtok(cmd[count-1],"\n");
		         		cmd[count]=NULL; 
				}
				pipe(pfd);
				pid_t child;
				child = fork();
				if(child==0)
				{
					close(pfd[0]); //close read end , child only write
					dup2(in,STDIN_FILENO);
					if(i<cmd_count-1)
						dup2(pfd[1],STDOUT_FILENO);
					else
						;//dup2(in,STDOUT_FILENO);
					execvp(cmd[0],cmd);
				}
				else
				{
					close(pfd[1]);
					wait(NULL);
					in=pfd[0];
				}
            		}
            
        	}
	}
	return 0;
}
