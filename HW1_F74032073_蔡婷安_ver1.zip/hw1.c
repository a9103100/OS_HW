#include <linux/init.h>
#include <linux/module.h>
#include <linux/kobject.h> 
#include <linux/sysfs.h> 
#include <linux/stat.h>
#include <linux/moduleparam.h>
#include <linux/string.h>

MODULE_LICENSE("Dual BSD/GPL");

static struct kobject *hw1_kobject;
static int mask=111;
static char *name1="swap_string";
static char *name2="calc";
static char *name3="sum_tree";
static int n=2;
static char input[100]="abcdef";
static char output[100]={0};

struct node
{
    int value;
    int tag;
}node;
static int count_n=0;
static struct node a[100];
static char input1[100]={0};

#define MAX_STACK_SIZE 100

static int stack[MAX_STACK_SIZE];
static int top=-1;
static char expr[MAX_STACK_SIZE];
static char expro[MAX_STACK_SIZE];
static char o[MAX_STACK_SIZE];
static char oo[MAX_STACK_SIZE];
static int isp[]={0,19,12,12,13,13,13,21};
static int icp[]={20,19,12,12,13,13,13,21};
static int answer1=0;
static int b=0;
static char temp[100]={0};
typedef enum {
	lparen, rparen, plus, minus, times, divide, mod, eos, operand
}precedence;

static precedence stack2[100];

void push(int num)
{
	if(top<100)
		stack[++top]=num;
}

int pop(void)
{
	if(top!=-1)
		return stack[top--];
	else	
		return 0;
}

void push2(precedence p)
{
	if(top<100)
		stack2[++top]=p;
}

precedence pop2(void)
{
	if(top!=-1)
		return stack2[top--];
	else
		return 0;
}

precedence getToken(char *symbol, int *n)
{
	*symbol=expr[(*n)++];
	switch (*symbol){
		case '(' : return lparen;
		case ')' : return rparen;
		case '+' : return plus;
		case '-' : return minus;
		case '/' : return divide;
		case '*' : return times;
		case '%' : return mod;
		case ' ' : return eos;
		//case '\0': return end;
		default : return operand;
	}
}

char printToken(precedence t)
{
	switch (t){
		case lparen : return '(';
		case rparen : return ')';
		case plus : return '+';
		case minus : return '-';
		case divide : return '/';
		case times : return '*';
		case mod : return '%';
		case eos : return ' ';
	  //case end : return '\0';
		default: return 0;
	}
}

void change(void)
{
	int i,c=0;
    c=strlen(expro);
	for(i=0;i<c;i++)
		expr[i]=expro[c-i-1];
}

void tansform(void)
{
    int i,c=0;
    c=strlen(expr);
    for(i=0;i<c;i++){
        if(expr[i]=='(')
           expr[i]=')';
        else if(expr[i]==')')
            expr[i]='(';
    }
}


void eval(void)
{
    precedence token;
	char symbol;
	int op1,op2,temp,sum;
	int n=0,i=0,j=0,exp=0,k=0,length=0;
	change();
	top=-1;
    length=strlen(expr);
	/*for(i=0;i<length-1;i++)
	{
		expr[i]=expr[i+1];
	}
	expr[length-1]=' ';*/
	expr[0]=' ';
    for(i=0;i<length;i++)
	{
        token=getToken(&symbol,&n);
        sum=0;
        temp=1;
	if(token==operand)
        {
            j=i;
            exp=0;
            while(expr[j]!=' '&&expr[j]!='+'&&expr[j]!='-'&&expr[j]!='*'&&expr[j]!='/'&&expr[j]!='%')
            {   
                temp=1;
                for(k=0;k<exp;k++)
                    temp=temp*10;
                sum=sum+(expr[j]-'0')*temp;
                j++;
                exp=exp+1;
            }
            push(sum);
            for(k=0;k<(j-i);k++)
                token=getToken(&symbol,&n);
            i=j;
        }
        else if(token==eos)
        {
        }
	//else if(token==end)
	//{}
	else{
		op1=pop();
		op2=pop();
		switch(token){
			case plus : push(op1+op2); break;
			case minus : push(op1-op2); break;
			case times : push(op1*op2); break;
			case divide : push(op1/op2); break;
			case mod : push(op1%op2); break;
	                default: break;
		}
	}
	}
	answer1=pop();
}

void prefix(void)
{
    int i=0,c=0,t=0;
    char symbol;
//	char temp[100];
	int length=0;
	precedence token;
	int n=0;
   /* while(oo[i]!='\0')
    {
        c=c+1;
        i=i+1;
    }*/
    c=strlen(oo);
//    oo[c]='!';
    if(oo[0]=='-')
    {
        for(i=1;i<c;i++)
        {
            o[i+3]=oo[i];
        }
        o[0]='0';
        o[1]=' ';
        o[2]='-';
        o[3]=' ';
    }
    else
    {
        for(i=0;i<c;i++)
        {
            o[i]=oo[i];
        }
    }
    c=strlen(o);
    for(i=0;i<c;i++)
    {
            expro[i]=o[i];
    }
    i=0;t=0;

	change();
	tansform();

	top=-1;
	stack2[0]=eos;
    length=strlen(expr);
    for(i=0;i<length;i++)
    {
        token=getToken(&symbol,&n);
        if(token==operand){
            temp[t]=symbol;
            t++;
        }
        else if(token==rparen){
			while(stack2[top]!=lparen){
				temp[t]=printToken(pop2());
				t++;
			}
			pop2();
		}
        else{
			while(isp[stack2[top]]>icp[token]){
				temp[t]=printToken(pop2());
				t++;
			}
			push2(token);
        }
    }
	while(top>=0){
		temp[t]=printToken(pop2());
		t++;
    }
   length=strlen(temp); 
	/*for(i=length-1;i>-1;i--){
        expro[length-i-1]=temp[i];
	}*/
	 for(i=0;i<length;i++)
                expro[i]=temp[length-i-1];

}

int check(int k)
{
    int i=0,c=0;
    for(i=0;i<count_n;i++)
    {
        if(i!=k){
            if((a[i].tag/10)==a[k].tag)
                c=c+1;
        }
    }   
    if(c==0)
        return 1;
    else
        return -1;
}

int evaluate(int k)
{
    int i=0,j,t,sum=0,c=0,compare[count_n];
    t=a[k].tag/10;
    while(t!=0)
    {
        compare[i]=t;  //存要加起來的數字的tag
        t=t/10;
        i=i+1;
        c=c+1;
    }
    /*for(j=0;j<c;j++)
    {
        printf("%d ",compare[j]);
    } */
    for(i=0;i<count_n;i++)
    {
        for(j=0;j<c;j++)
        {
            if(a[i].tag==compare[j])
                sum=sum+a[i].value;
        }
    }
    sum=sum+a[k].value;
    //printf("sum=%d ",sum);
    return sum;
}

static ssize_t swap_show(struct kobject *kobj, struct kobj_attribute *attr,char *buf)
{
	int c=0,i=0;
        while(input[i]!='\0')
        {
                c=c+1;
                i=i+1;
        }
        //printk(KERN_INFO "%d \n",c);
        for(i=n;i<c;i++)
        {
                output[i-n]=input[i];
                //printk(KERN_INFO "%c \n",input[i]);
        }
        for(i=0;i<n;i++)
        {
                output[c-n+i]=input[i];
                //printk(KERN_INFO "%c \n",input[i]);
        }
        for(i=0;i<c;i++){
                printk(KERN_ALERT "%c",output[i]);
        }

	return sprintf(buf, "%s \n",output);
}

static ssize_t swap_store(struct kobject *kobj, struct kobj_attribute *attr,const char *buf, size_t count)
{
        //sscanf(buf, "%du", &n);
	sscanf(buf, "%d %s",&n, input);
        return count;
}

static ssize_t calc_show(struct kobject *kobj, struct kobj_attribute *attr,char *buf)
{
   //scanf("%[^\n]",oo);
    int i=0,t=0,ans=0;
//	int c=0;
  //  c=strlen(oo);
    for(i=0;i<b;i++)
    {
        if(oo[i]=='+'||oo[i]=='-'||oo[i]=='*'||oo[i]=='/'||oo[i]=='%')
            t=t+1;
    }
    if(t==0)
    {
	    for(i=0;i<b;i++)
	    {
		    ans=ans*10+(oo[i]-48);
	    }
    }
    else{
	 prefix();
       	 eval();
         ans=answer1;
    }
        return sprintf(buf, "%d \n",ans);
//	return sprintf(buf,"%s \n",expr);
//	c=strlen(expr);
//	if(expr[c]==' ')	yes=111;
//	else yes=222;
//	return sprintf(buf,"%c",expr[0]);
}

static ssize_t calc_store(struct kobject *kobj, struct kobj_attribute *attr,const char *buf, size_t count)
{
    int i=0;
    /*while(buf[i]!='\0')
    {   
        oo[i]=buf[i];
        i++;
    }*/
	for(i=0;i<count;i++)
	{
		oo[i]=buf[i];
	}
	b=count-1;
	return count;
}
static ssize_t sum_tree_show(struct kobject *kobj, struct kobj_attribute *attr,char *buf)
{
    //char input1[100];
    int name=0; 
    int i=0,temp1=0,length=0;
    int answer[100]={0};
    char s[100];
    int offset=0;
    //scanf("%[^\n]",input);
	count_n=0;
	length=strlen(input1);
    for(i=0;i<length;i++)
    {
        if(input1[i]=='(')
        {
            temp1=i+1;
            a[count_n].value=input1[temp1]-48;
            a[count_n].tag=name*10+1;
            name=a[count_n].tag;
            temp1=temp1+1;
            while(input1[temp1]!='('&&input1[temp1]!=')'&&input1[temp1]!=' ')
            {
                a[count_n].value=a[count_n].value*10+(input1[temp1]-48);
                temp1=temp1+1;
            }
            count_n=count_n+1;
            //i=i+1;
        }
        else if(input1[i]==')')
        {
            temp1=i+1;
            if(input1[temp1]==')')
            {
              //  i=i+1;
                break;
            }
            a[count_n].value=input1[temp1]-48;
            a[count_n].tag=name/10+1;
            name=a[count_n].tag;
            temp1=temp1+1;
            while(input1[temp1]!='('&&input1[temp1]!=')'&&input1[temp1]!=' ')
            {
                a[count_n].value=a[count_n].value*10+(input1[temp1]-48);
                temp1=temp1+1;
            }
            count_n=count_n+1;
           // i=i+1;    
        }
        else if(input1[i]==' ')
        {
            temp1=i+1;
            a[count_n].value=input1[temp1]-48;
            a[count_n].tag=name+1;
            name=a[count_n].tag;
            temp1=temp1+1;
            while(input1[temp1]!='('&&input1[temp1]!=')'&&input1[temp1]!=' ')
            {
                a[count_n].value=a[count_n].value*10+(input1[temp1]-48);
                temp1=temp1+1;
            }
            count_n=count_n+1;
           // i=i+1;
        }
        else{}
            //i=i+1;
    }
    
    /*for(i=0;i<count;i++)
    {
        printf("%d ",a[i].value);
    }
    printf("\n");
    for(i=0;i<count;i++)
    {
        printf("%d ",a[i].tag);
    }
    printf("\n");*/
    //int answer[count_n];
    temp1=0;
    for(i=0;i<count_n;i++)
    {
        if(check(i)==1)
        {
            //printf("%d:",a[i].value);
            answer[temp1]=evaluate(i);
            //printf("ans:%d ",answer[temp]);
            temp1=temp1+1;
        }    
    }
    for(i=0;i<temp1;i++)
    {
        offset=offset+sprintf(s+offset,"%d, ",answer[i]);
    	//sprintf(s+i,"%d, ",answer[i]);
    }
	s[offset-2]='\n';
	return sprintf(buf,"%s",s);
    //return sprintf(buf,"%d",answer[0]);
}
static ssize_t sum_tree_store(struct kobject *kobj, struct kobj_attribute *attr,const char *buf, size_t count)
{
    int i=0;
    /*while(buf[i]!='\0')
    {   
        input1[i]=buf[i];
        i++;
    }*/
	for(i=0;i<count;i++)
	{
		input1[i]=buf[i];
	}
        return count;
}


static struct kobj_attribute swap_attribute = __ATTR(swap, 0660, swap_show, swap_store);
static struct kobj_attribute calc_attribute = __ATTR(calc, 0660, calc_show, calc_store);
static struct kobj_attribute sum_tree_attribute = __ATTR(sum_tree, 0660, sum_tree_show, sum_tree_store);

module_param(mask,int,S_IRUGO);
module_param(name1,charp,S_IRUGO);
module_param(name2,charp,S_IRUGO);
module_param(name3,charp,S_IRUGO);

static int __init create_swap(void)
{
	int error = 0;

        pr_debug("Module initialized successfully \n");
        hw1_kobject = kobject_create_and_add("hw1",kernel_kobj);
        if(!hw1_kobject)
                return -ENOMEM;
	if(mask>9){
	if(mask/100==1){
        	swap_attribute.attr.name=name1;
		error = sysfs_create_file(hw1_kobject,&swap_attribute.attr);
        }
    if(mask%100/10==1){
        	calc_attribute.attr.name=name2;
		error = sysfs_create_file(hw1_kobject,&calc_attribute.attr);
        }
	 if(mask%100%10==1){
                sum_tree_attribute.attr.name=name3;
                error = sysfs_create_file(hw1_kobject,&sum_tree_attribute.attr);
        }
	}
	else
	{
		if(mask/8==1){
			calc_attribute.attr.name=name2;
                	error = sysfs_create_file(hw1_kobject,&calc_attribute.attr);
		}
		if(mask%8==1){
		 	sum_tree_attribute.attr.name=name3;
                	error = sysfs_create_file(hw1_kobject,&sum_tree_attribute.attr);
		}
	}
	if (error) {
                pr_debug("failed to create the swap file in /sys/kernel/kobject_hw1 \n");
        }

        return error;
}

static void __exit cleanup_swap(void)
{
	pr_debug ("Module un initialized successfully \n");
        kobject_put(hw1_kobject);
}

module_init(create_swap);
module_exit(cleanup_swap);

